# JediSec OSINT Sovereign Threat Grid

## Overview

This bundle includes Phases I-V of the JediSec OSINT Aggregation System.

### Phases Included:

- Phase I — Twitter/X Aggregation
- Phase II — Telegram Aggregation
- Phase III — Bluesky Aggregation
- Phase IV — Reddit Aggregation
- Phase V — Dark Web Aggregation

### Install Dependencies

```bash
pip install -r requirements.txt
sudo apt install python3-tk chromium-chromedriver tor
```

### Launch Control Panel

```bash
python3 jedisec_osint_gui.py
```

