import tkinter as tk
from tkinter import messagebox
import subprocess
import os

SCRIPTS = {
    "Phase I - Twitter/X Aggregation": "Phase-I-X/x_osint_aggregator.py",
    "Phase II - Telegram Aggregation": "Phase-II-Telegram/telegram_osint_aggregator.py",
    "Phase III - Bluesky Aggregation": "Phase-III-Bluesky/bluesky_osint_aggregator.py",
    "Phase IV - Reddit Aggregation": "Phase-IV-Reddit/reddit_osint_aggregator.py",
    "Phase V - Dark Web Aggregation": "Phase-V-DarkWeb/darkweb_osint_aggregator.py"
}

class JediSecOSINT:
    def __init__(self, master):
        self.master = master
        master.title("JediSec OSINT Aggregation Grid")
        tk.Label(master, text="JediSec Unified Aggregation Control Panel", font=("Arial", 16, "bold")).pack(pady=10)

        for phase, script in SCRIPTS.items():
            button = tk.Button(master, text=phase, font=("Arial", 12), width=40,
                                command=lambda s=script, p=phase: self.run_script(s, p))
            button.pack(pady=5)

        self.quit_button = tk.Button(master, text="Exit", font=("Arial", 12), width=20, command=master.quit)
        self.quit_button.pack(pady=10)

    def run_script(self, script, phase):
        if not os.path.exists(script):
            messagebox.showerror("Error", f"Script file not found: {script}")
            return

        response = messagebox.askyesno("Launch Aggregator", f"Launch {phase}?")
        if response:
            try:
                subprocess.Popen(["python3", script])
                messagebox.showinfo("Aggregator Launched", f"{phase} is now running in background.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to launch: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = JediSecOSINT(root)
    root.mainloop()
